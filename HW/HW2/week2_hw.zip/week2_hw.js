//1.
//These could change for each employee
let empName = "John Doe";
let empAge = 35;
let empPosition = "Doctor";

//These are to stay the same
const comName = "UPMC";
const isFullTime = true;

//Logs them into Console
console.log("Employee Name: " + empName);
console.log("Employee Age: " + empAge);
console.log("Employee Position: " + empPosition);
console.log("Company Name: " + comName);
console.log("Is Full-Time Employee: " + isFullTime);

//2.
//Declared Variable
let myVariable = "Wonder Bread";

//typeof to determine type
let variableType = typeof myVariable;

//Logs them into Console
console.log("Value of myVariable: " + myVariable);
console.log("Data type of myVariable: " + variableType);

//3.
//Declare 42 as String
let numString = "42";

//Convert to Number
let numValue = Number(numString);

//Add 10 to the number
let result = numValue + 10;

//Log in Console
console.log("Original numString: " + numString);
console.log("Converted numValue: " + numValue);
console.log("Result after adding 10: " + result);

//4.
//Declare Variables
let a = 25;
let b = 5;

//Comparison using ==
console.log("a == b:", a == b);
//Comparison using ===
console.log("a === b:", a === b);
//Comparison using !=
console.log("a != b:", a != b);
//Comparison using !==
console.log("a !== b:", a !== b);
//Comparison using >
console.log("a > b:", a > b);
//Comparison using <
console.log("a < b:", a < b);
//Comparison using >=
console.log("a >= b:", a >= b);
//Comparison using <=
console.log("a <= b:", a <= b);
