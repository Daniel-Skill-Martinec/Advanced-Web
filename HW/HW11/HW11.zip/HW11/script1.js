const user = 'John';
console.log(`Logging the username from external JS: ${user}`);