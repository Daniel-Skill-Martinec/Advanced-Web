import message from './message';
import './css/styles.css';

console.log(message);
// console.log(message.text);
console.log('Testing Auto Reload');