const message = {
    is: 1,
    text: 'Hello World'
}

export default message;